
import './index.css'
import FAQ from './components/FAQ'

function App() {
  return (
    <div className="app">
      <div className="faq-card">
        <FAQ />
      </div>
    </div>
  )
}

export default App
